
for i in range(1,10): # i = 5
    for j in range(1,i+1): # i =2
        print(f"{i}x{j}={i*j}",end=" ")
    print()
