# print("hello world..")
# print("hello world..2")
# print("hello world..")
# print("hello world..")
# win:ctrl+?
# mac : Alt + ?