
# count = 0
# while count < 10 :
#     # count += 1
#     print("loop",count)
count = 0
while True:
    count += 1
    print(".....",count)

