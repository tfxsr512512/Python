
for i in range(11):# i=7
    if i <= 5:
        print("* " * i )
    else:
        print("* " * (10-i))