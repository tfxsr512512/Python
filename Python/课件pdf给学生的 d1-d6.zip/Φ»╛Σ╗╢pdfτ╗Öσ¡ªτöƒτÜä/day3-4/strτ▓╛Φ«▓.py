
s = "alex"
s.strip()
