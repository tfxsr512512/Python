


# staff_list = []
# for i in range(1,31):
#     staff_list.append(f"staff-{i}")
#
# print(staff_list)

