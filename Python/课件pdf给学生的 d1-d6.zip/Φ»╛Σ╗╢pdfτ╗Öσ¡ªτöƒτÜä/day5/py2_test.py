# -*- encoding:utf-8 -*-
name = "路飞学城"
print(name)
