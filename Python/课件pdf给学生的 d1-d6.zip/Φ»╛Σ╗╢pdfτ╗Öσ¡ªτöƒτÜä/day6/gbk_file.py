
f = open("file_gbk.txt", encoding="gbk")
print(f.read())