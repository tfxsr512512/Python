
f = open("from_win/file_gbk2.txt",'r',encoding="gbk")
print(f.read())