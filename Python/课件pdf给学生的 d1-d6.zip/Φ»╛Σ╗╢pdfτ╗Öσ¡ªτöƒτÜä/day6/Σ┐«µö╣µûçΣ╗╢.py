
f = open("model_contacts.txt", "r+")

# data = f.read() # 先把文件内容全读到内存
# data_new = data.replace("罗梦竹","刘翠花TracyLiu") # 替换
# f.seek(0) # 光标移到0
# f.truncate()  # 清空
# f.write(data_new) # 写入新内容


f.close()



