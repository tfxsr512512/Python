import os

os.remove("model_contacts.txt")