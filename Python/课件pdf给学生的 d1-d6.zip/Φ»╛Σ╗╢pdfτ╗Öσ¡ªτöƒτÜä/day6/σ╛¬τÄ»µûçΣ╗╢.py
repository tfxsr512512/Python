
f = open("model_contacts.txt",) # 默认`rt`模式
# print(f.readline()) # 读第1行
# print(f.readline()) # 读第2行
# print(f.readline()) # 读第3行
#
# print('----循环读后面的-----'),
#
# for line in f:
#     print(f.readline())

print(f.encoding)
f.wr
print(f.read(3)) # 读取3个字符