
f = open("my_first_file2.txt","x")
f.write("My name is Alex, 哈哈哈\n")
f.write("昨天下班去酒吧...\n")
f.write("有个9分的漂亮学生跟我们一起玩.")

# f.close() # 关闭
