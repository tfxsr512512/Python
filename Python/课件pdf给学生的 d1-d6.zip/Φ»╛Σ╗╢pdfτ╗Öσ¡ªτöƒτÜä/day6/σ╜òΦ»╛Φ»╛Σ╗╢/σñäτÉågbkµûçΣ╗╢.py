# -*- encoding:utf-8 -*-

# 告诉解释器，后面的代码是用什么编码的，
f = open("../from_win/file_gbk2.txt",encoding="gbk")
print(f.read())